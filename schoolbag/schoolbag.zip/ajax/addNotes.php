<?php
$justInclude=true;
include("../config.php");

$typesAllowed=array("P","T");
$postVariablesRequired=array("params","checked");
include("checkAjax.php");

$post=explode("&",$_POST["params"]);
$postValues=array();
foreach($post as $v){
	$tmp=explode("=",$v);
	$postValues[$tmp[0]]=$tmp[1];
}
$student=$_SESSION["userID"];
if(isset($postValues["student"])) $student=$postValues["student"];
if($_POST["text"]==""){
		$checkSql="DELETE FROM notes WHERE schoolID=".$_SESSION["schoolID"]." AND studentID=".$student." AND timeslotID='".$postValues["timeslotID"]."' AND date='".implode("-",array_reverse(explode("|",$postValues["date"])))."' AND class=ID".$postValues["class"];

		mysql_query($checkSql);
} else {
			$checkSql="UPDATE notes SET status=".$_POST["checked"].", text='".addslashes($_POST["text"])."' WHERE schoolID=".$_SESSION["schoolID"]." AND studentID=".$student." AND timeslotID='".$postValues["timeslotID"]."' AND date='".implode("-",array_reverse(explode("|",$postValues["date"])))."' AND classID=".$postValues["class"];
//	echo $checkSql;
	$checkResult=mysql_query($checkSql);
	$updated=true;
	if($checkResult>0){
		$insertSql="INSERT INTO notes SET status=".$_POST["checked"].", text='".addslashes($_POST["text"])."', schoolID=".$_SESSION["schoolID"].", studentID=".$student.", timeslotID='".$postValues["timeslotID"]."', date='".implode("-",array_reverse(explode("|",$postValues["date"])))."',classID=".$postValues["class"];
		$updated=false;
		mysql_query($insertSql);
	}
}
?>