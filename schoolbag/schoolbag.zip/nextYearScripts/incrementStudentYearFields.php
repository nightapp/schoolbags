<?php
if(!isset($_POST["pwd"]) || $_POST["pwd"]!=md5("schoolBag")) die("Error in request"); 
$justInclude=true;

include_once("../config.php");
$sqlif="if(users.year<>3,users.year+1,if(schoolinfo.allTY=0,users.year+2,if(schoolinfo.allTY=2,users.year+1,9)))";

$sql="UPDATE users,schoolinfo SET users.year=".$sqlif." WHERE users.schoolID=schoolinfo.schoolID AND users.Type='P'";
echo $sql;
$sqlresult=mysql_query($sql);
echo mysql_affected_rows();

?>