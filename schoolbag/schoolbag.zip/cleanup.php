<?php 
$dir="information/";
include("includes/listdir.php");


?>