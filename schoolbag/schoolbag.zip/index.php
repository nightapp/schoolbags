<?php 
$required=array('S','T','A','P');
include("config.php");?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="schoolBag.css" />
<title>Welcome to <?php echo $websiteTitle;?></title>
<script src="scripts/jquery.js" type="text/javascript" language="javascript"></script>
<script src="scripts/vmenu.js" type="text/javascript" language="javascript"></script>
<script language="javascript" type="text/javascript">
$(document).ready(function(){
	$("#forgotPassword").click(function(){
		$.post("includes/generic/formOverlayForms/forgotPassword.php",{email:$("#email").val()},function(data){
			showFormOverlay(data);
		})
	})
	$("#passwordReminderForm #submit").live("click",function(){
		showFormOverlay("<div class='subHeading'>Sending Password Reminder...</div>");
		$.post("ajax/forgotPassword.php",$(this).parent().serialize(),function(data){
			showFormOverlay("<div class='subHeading'>Password Reminder</div>"+data);
		})
	})
	hgt=$(window).height()-30;
	wth=$(window).width();
	$("#emailLink").css({marginTop:hgt+'px'});
	$('body').width(wth);
	$('#animation').css({marginTop:'-150px',marginLeft:'-1024px'});
	$('#animation').animate({marginTop:'0px',opacity:1},2000);
})
</script>
</head>

<body style="overflow:hidden;background-image:url(background_images/blueStrip.gif);background-position:center -1px">
<div id="animation" style="left:50%;background-image:url(background_images/loginLogo.gif);position:absolute;display:block;height:190px;width:2048px;z-index:10;opacity:0"></div>
<div id="centeredContent" style="background-color:none;background-image:none;padding-top:200px;height:504px">
<br /><br />
<form id="loginForm" method="post">
<div style="text-align:center;width:45%;float:left;display:inline"><label>Email Address: </label><input type="text" name="username" id="email" /></div>
<div style="text-align:center;width:45%;float:left;display:inline"><label>Password: </label><input type="password"  name="password" /></div>
<div style="text-align:center;width:10%;float:left;display:inline"><input type="submit" value="Log In"  /></div>
</form><br />
<br />

<div style="text-align:center;width:49.5%;float:left;display:inline">
<a href="signUpPage.php" class="indexLinks">Sign Up &raquo;</a>
</div>
<div style="text-align:center;width:49.5%;float:left;display:inline">
<a href="#" id="forgotPassword"  class="indexLinks">Forgot Password &raquo;</a>
</div>
<div id="formOverlay">
</div>
<?php if(isset($_SESSION["invalidLogin"])){
?>
<div id="invalidLogin" style="text-align:center;width:100%"><b style="color:#FF0000">The details provided were not valid</b></div>
<?php 
unset($_SESSION["invalidLogin"]);
}
?>
</div>
<div id="emailLink" style="width:800px;left:50%;top:0px;margin-left:-400px;display:block;text-align:right;position:absolute;z-index:999">e-mail: <a href="mailto:info@schoolbag.ie">info@schoolbag.ie</a></div>

</body>
</html>
