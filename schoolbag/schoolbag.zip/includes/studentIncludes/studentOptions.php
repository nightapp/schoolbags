<div id="options">
<div class="option" title="Go to journal" rel="studentPage.php?subPage=journal"><img src="background_images/journal.gif" /><br />Journal
</div>
<div class="option" title="View timetable" rel="studentPage.php?subPage=timetable"><img src="background_images/timetable.gif" /><br />Timetable</div>
<div class="option" title="Go to copies" rel="studentPage.php?subPage=copies"><img src="background_images/notes.gif" /><br />Copies</div>
<div class="option" title="View resources" rel="studentPage.php?subPage=dropBox"><img src="background_images/foldericon.gif" /><br />Resources</div>
<div class="option" title="View e-Books" rel="studentPage.php?subPage=books"><img src="background_images/books.gif" /><br />eBooks</div>
<div class="option" title="View Noticeboard" rel="studentPage.php?subPage=noticeboard"><img src="background_images/noticeBoard.gif" /><br />Noticeboard</div>
</div>