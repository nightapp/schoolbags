<div id="googleDiv" class="middleDiv">
<form id="googleForm" action="http://www.bing.com/search" method="get" target="_blank">
<label>Library:</label><input type="text" name="q" id="searchQuery" /><input type="submit" value="Search Bing &raquo;" />
</form>
</div>