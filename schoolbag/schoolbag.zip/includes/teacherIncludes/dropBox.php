<?php 
if(isset($_POST["SubSubFolder"])){
//include("upload.php");
}
	function ordinalize($number) {
		if (in_array(($number % 100),range(11,13))){
			return $number.'th';
		} else {
			switch (($number % 10)) {
				case 1:
					return $number.'st';
				break;
					case 2:
				return $number.'nd';
					break;
				case 3:
					return $number.'rd';
				default:
					return $number.'th';
				break;
			}
		}
	}
?>
<div class="middleDiv" id="ebookList">
<?php 
include("includes/generic/listdir.php");
if(isset($_GET["class"])){
	if(strpos($_GET["class"],"./")!==false) die("Error: Access Denied");
		$addPath=$_GET["class"]."/";
}
$myBooksPath=$schoolPath.strtoupper($_SESSION["userType"])."/".$_SESSION["userID"]."/dropBox/".$addPath;
$myBooksPath=str_replace("//","/",$myBooksPath);
if(strrpos("/",$myBooksPath)===0) substr($myBooksPath,0,strlen($myBooksPath));
$myBooks=array();
if(is_dir($myBooksPath)){//there are eBooks
?>
<script type="text/javascript">
$(document).ready(function(){
	$('#ebookUploadForm').slideUp(1);	
	$('#uploadLink').click(function(){
		$("#uploadLink").slideUp();
		$('#ebookUploadForm').slideDown();
		return false;
	});
})
</script>
	<div id="ebookListHeading" class="subHeading">
	Resources
	</div>
	<div><a id="uploadLink" href="" style="cursor:pointer"><img src="background_images/newResource.gif" /></a>
		<div id="ebookUploadForm" style="overflow:hidden">
			<form action="<?php $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];?>" method="post"  enctype="multipart/form-data" id="uploadBookForm">
				<label>File: </label><input type="file" name="fileData" id="fileToUpload" /><br />
				<label>For Class: </label><?php if($_SESSION["userType"]){ include("includes/teacherIncludes/getClassSelect.php");} else {include("includes/studentIncludes/getClassSelect.php");}?><br />
				<input type="hidden" value="dropbox" name="SubFolder" />
				<input type="submit" value="Upload resource" />
			</form>
		</div>
	</div>
<ul>
<?php
	include_once("includes/getSubjects.php");
	if(!isset($_GET["class"])){
		$directories=getfilelist($myBooksPath."/","DIR");
		foreach($directories as $dir){
			if(strrpos("/",$dir)===0) substr($dir,0,strlen($dir));
			
	$sql="SELECT * from classlist WHERE schoolID='".$_SESSION["schoolID"]."' AND classID='".basename($dir)."' LIMIT 1";
			$result=mysql_query($sql);
		
			$row=mysql_fetch_array($result);
			$subject=$subjects[$row["subjectID"]];
		
	?>
			<li><a class="head" href="<?php echo $_SERVER['SCRIPT_NAME']."?".$_SERVER['QUERY_STRING'];?>&class=<?php echo basename($dir);?>"><?php echo ordinalize($row["year"])." year, ".$subject." ".$row["extraRef"];?></a></li>
<?php //Class header ?>
	<?php
		} ?></ul><?php
	} else {
	$sql="SELECT * from classlist WHERE schoolID='".$_SESSION["schoolID"]."' AND classID='".$_GET["class"]."' LIMIT 1";
			$result=mysql_query($sql);
		
			$row=mysql_fetch_array($result);
			$subject=$subjects[$row["subjectID"]];
		$dir=$myBooksPath;
		$myBooks=array();
		foreach($bookFileTypes as $extention){
			$myBooks=array_merge($myBooks,getfilelist($dir."/",$extention));
		}
		ksort($myBooks);
		?><h3><?php echo ordinalize($row["year"])." year, ".$subject." ".$row["extraRef"];?></h3><ul><?php
		foreach($myBooks as $v){
			$v=str_replace("//","/",$v);
			?>
			<li><a href="<?php echo $v;?>" target="_blank"><?php echo basename($v);?></a></li>
			<?php 
		}
		?>
		</ul>
		<?php
	}
} else {
?>
<div id="ebookListHeading" class="subHeading">
You currently do not have any resources
</div>
	<div style="font-size:14px">
		<div id="ebookUploadForm">
			<form action="<?php $_SERVER['PHP_SELF']."?".$_SERVER['QUERY_STRING'];?>" method="post"  enctype="multipart/form-data" id="uploadBookForm">
				<label>File: </label><input type="file" name="fileData" id="fileToUpload" /><br />
				<label>For Class: </label><?php if($_SESSION["userType"]){ include("includes/teacherIncludes/getClassSelect.php");} else {include("includes/studentIncludes/getClassSelect.php");}?><br />
				<input type="hidden" value="dropBox" name="SubFolder" />
				<input type="submit" value="Upload Resource" />
			</form>
		</div>
	</div>
<?php
}
?>
</div>