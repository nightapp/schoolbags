<div id="teachersSubjects" style="width:100%;text-align:center">
<?php 
include_once("includes/getSubjects.php");
include_once("includes/teacherTeaches.php");
$border=false;
$borderExtra="";
foreach($teacherTeaches as $rowTeachers){
	if($border){
		$borderExtra=";border-left:1px solid brown";
	}
	$border=true;
	?>
<span style=""><?php echo $subjects[$rowTeachers["subject"]];?></span><?php }?></div>