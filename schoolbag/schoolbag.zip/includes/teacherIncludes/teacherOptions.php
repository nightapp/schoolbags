<div id="options">
<div class="option" title="Go to journal" rel="teacherPage.php?subPage=journal"><img src="background_images/journal.gif" /><br />Journal</div>
<div class="option" title="View timetable" rel="teacherPage.php?subPage=timetable"><img src="background_images/timetable.gif" /><br />Timetable</div>
<div class="option" title="Go to e-Books" rel="teacherPage.php?subPage=books"><img src="background_images/books.gif" /><br />eBooks</div>
<div class="option" title="Go to noticeboard" rel="teacherPage.php?subPage=noticeboard"><img src="background_images/noticeboard.gif" /><br />Noticeboard</div>
<div class="option" title="Add to resources" rel="teacherPage.php?subPage=dropBox"><img src="background_images/foldericon.gif" /><br />Resources</div>
</div>