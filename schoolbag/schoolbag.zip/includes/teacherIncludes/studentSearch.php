<div id="findStudentDiv" class="middleDiv">
<form id="findStudentForm">
<label>Student:</label><input type="text" name="searchQuery" id="searchQuery" />
<input type="button" id="submit" value="Search for student &raquo;" />
</form>
</div>