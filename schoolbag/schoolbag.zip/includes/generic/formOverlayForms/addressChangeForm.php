<div class="subHeading" style="width:100%">Change Address</div><br />
<form id="addressChangeForm" class="formInOverlay" style="margin:5px;">
<label>Address:</label><input type="text" id="address" name="address" /><br /><br />
<input id="submit" type="button" value="Change Address &raquo;" />
</form>