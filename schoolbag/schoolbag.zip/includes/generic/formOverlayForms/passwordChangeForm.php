<div class="subHeading" style="width:100%">Change Password</div><br />
<form id="passwordChangeForm" class="formInOverlay" style="margin:5px;">
<label style="width:170px">Old Password:</label><input type="password" id="oldPass" name="oldPass" /><br /><br />
<label style="width:170px">New Password:</label><input type="password" name="newPass" id="newPass" /><br /><br />
<label style="width:170px">Confirm Password:</label><input type="password" id="confirmPass" name="confirmPass" /><br /><br />
<input id="submit" type="button" value="Change Password &raquo;" />
</form>