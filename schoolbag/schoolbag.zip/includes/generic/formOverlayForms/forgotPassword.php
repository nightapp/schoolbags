<div class="subHeading" style="width:100%">Forgot Password</div><br />
<form id="passwordReminderForm" class="formInOverlay" style="margin:5px;">
<label>Email:</label><input type="text" name="email" value="<?php echo $_POST["email"];?>" /><br /><br />
<input id="submit" type="button" value="Send Password Reminder &raquo;" />
</form>