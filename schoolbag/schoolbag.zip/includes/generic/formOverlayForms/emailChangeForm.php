<div class="subHeading" style="width:100%">Change Email</div><br />
<form id="emailChangeForm" class="formInOverlay" style="margin:5px;">
<label>New Email:</label><input type="text" name="newEmail" id="newEmail" /><br /><br />
<label>Confirm Email:</label><input type="text" id="confirmEmail" name="confirmEmail" /><br /><br />
<input id="submit" type="button" value="Change Email &raquo;" />
</form>