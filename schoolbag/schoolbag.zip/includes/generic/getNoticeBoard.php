<?php if(!isset($_GET["noticeBoard"])) $_GET["noticeBoard"]="P";?>
<div id="noticeBoard" class="middleDiv">
<script type="text/javascript" language="javascript">
$(document).ready(function(){
	$(".deleteNewsItem").click(function(){
		if(confirm("Are you sure you want to delete this notice")){
			clicked=$(this);
			$.post("ajax/deleteFromNoticeBoard.php",$(this).parent().serialize(),function(data){
				alert(data);
				clicked.parent().parent().parent().remove();
			})
		}
	})
	$(".editNewsItem").click(function(){
		document.location.href=$(this).attr("rel");
	})
})
</script>
<div id="noticeBoardHeader" class="subHeading">School Notice Board</div>
<?php if($_SESSION["userType"]!="P" && !isset($_GET["smallnoticeboard"])){?>
<div style="height:74px;overflow:hidden;margin-left:275px;text-align:center">
<div class="option" title="Go to noticeboard (full)" rel="<?php echo $userTypePage[$_SESSION["userType"]];?>?subPage=noticeboard&noticeBoard=P"><img src="background_images/noticeboard.gif" /><br />Full</div>
<div class="option" title="Go to noticeboard (staff only)" rel="<?php echo $userTypePage[$_SESSION["userType"]];?>?subPage=noticeboard&noticeBoard=T"><img src="background_images/staffnoticeboard.gif" /><br />Staff only</div>
<div class="option" title="Add to noticeboard" rel="<?php echo $userTypePage[$_SESSION["userType"]];?>?subPage=addToNoticeboard&noticeBoard=<?php echo $_GET["noticeBoard"];?>"><img src="background_images/addtonoticeboard.gif" /><br />Add new</div>
</div>
<?php
}
$from=0;
$more=false;
if(isset($_GET["startFrom"]) && $_GET["startFrom"]>0) $from=$_GET["startFrom"];
$valuesArray=array();
$val="'".$_SESSION["userType"]."'";
if(isset($_GET["noticeBoard"])){
	$tmp=$visibleNoticeBoards[$_GET["noticeBoard"]];
	unset($visibleNoticeBoards);
	$visibleNoticeBoards[$_GET["noticeBoard"]]=$tmp;
}
foreach($visibleNoticeBoards as $k=>$currentList){
	$tmpArray=explode(",",$currentList);
	if(in_array($val,$tmpArray)){
		$valuesArray[count($valuesArray)]=$k;
	}
}
 
if(isset($_GET["smallnoticeboard"])){
$sql="SELECT * FROM noticeboard,users WHERE (users.schoolID='".$_SESSION["schoolID"]."' || users.schoolID=0) AND noticeboard.userType IN('".implode("', '",$valuesArray)."') AND users.userID=noticeboard.uploadedBy ORDER BY date DESC LIMIT ".$from.",4";
} else{
$sql="SELECT * FROM noticeboard,users WHERE (users.schoolID='".$_SESSION["schoolID"]."' || users.schoolID=0) AND noticeboard.userType IN('".implode("', '",$valuesArray)."') AND users.userID=noticeboard.uploadedBy ORDER BY date DESC LIMIT ".$from.",11";//Get 11 rows (Last one only to see if there is more)
}
?><?php
$i=0;
$result=mysql_query($sql);
while($row = mysql_fetch_array($result)){
$i++;
$more=false;
if($i<=10){
?>
<div class="notice" style="display:block">
	<div class="noticeLeft" style="text-align:center">
		<?php echo date("d/m/Y",strtotime($row["date"]));?><br>
		<?php echo date("H:i",strtotime($row["date"]));?>
		<?php if($_SESSION["userID"]==$row["uploadedBy"] && $_SESSION["schoolID"]==$row["schoolID"]){?><br />
		<a title="Edit News Item" class="editNewsItem" style="display:inline" rel="<?php echo $_SERVER['PHP_SELF'];?>?subPage=addToNoticeboard&date=<?php echo $row["date"];?>&schoolID=<?php echo $row["schoolID"];?>"><img src="background_images/edit-icon.png" style="height:20px"/></a>
		<form style="display:inline">		<a title="Delete News Item" class="deleteNewsItem"><img src="background_images/Delete-icon.png" style="height:20px"/></a>
		<input type="hidden" value="<?php echo $row["date"];?>" name="date" />
		</form>
		<?php }?>
	</div>
	
	<div class="noticeRight">
	<?php echo $row["text"];?>
	<?php if($row["Type"]=="A"){
		$imgfile="background_images/smallLogo.gif";
	} elseif($row["Type"]=="S"){
		$imgfile=$_SESSION["schoolPath"]."S/crest.jpg";	
	} else {
		$imgfile=$_SESSION["schoolPath"].$row["Type"]."/".$row["userID"]."/image.jpg";	
	}
	if(file_exists($imgfile)){
	?><img src="<?php echo $imgfile;?>" style="width:70px;float:right;margin-top:4px" />	<?php } ?>
<br style="clear:both;" />
	<i style="float:right;font-size:9px">Added By <?php echo $row["FirstName"]." ".$row["LastName"];?></i>
	</div>
</div>
<?php 
	} else {
		$more=true;
	}
}?><br>
<br>
<div class="subFooter"><div style="width:50%;float:left;display:block;text-align:left"><?php if($from>0){?><a href="<?php echo $_SERVER['SCRIPT_NAME']."?subPage=noticeboard&startFrom=".($from-10);?>">&laquo; back</a><?php } ?></div><div style="width:50%;float:left;display:block;text-align:right"><?php if($more){?><a href="<?php echo $_SERVER['SCRIPT_NAME']."?subPage=noticeboard&startFrom=".($from+10);?>">more &raquo;</a><?php } ?></div>
</div>
</div>