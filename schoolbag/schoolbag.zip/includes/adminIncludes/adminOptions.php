<div id="options">
<div class="option" title="New School" rel="adminPage.php?subPage=newSchool"><img src="background_images/newschool.gif" /><br />New</div>
<div class="option" title="View Schools" rel="adminPage.php?subPage=viewSchools"><img src="background_images/viewSchools.gif" />Schools</div>
<div class="option" title="Add to noticeboard" rel="adminPage.php?subPage=addToNoticeboard&noticeBoard=P"><img src="background_images/addtonoticeboard.gif" /></div>
<div class="option" title="View noticeboard" rel="adminPage.php?subPage=noticeboard&noticeBoard=P"><img src="background_images/noticeboard.gif" /><br />Noticeboard</div>
</div>
</div>