<?php 
$add="";
if($upOneLevel){ $add="../"; }?>
<script src="<?php echo $add;?>scripts/vmenu.js"></script>
<link rel="stylesheet" href="<?php echo $add;?>vmenu.css" type="text/css" />

<div class="vmenu formOverlayNoHide" id="vmenu">
<div style="clear:both;width:100%;height:28px;display:block"></div>

	<div class="first_li">
		<span>Log Out</span>
	</div>	
</div>