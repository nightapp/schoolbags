<div id="options">
<div class="option" title="Edit Timetable Configuration" rel="schoolPage.php?subPage=timetable"><img src="background_images/timetable.gif" /><br />Timetable</div>
<div class="option" title="Noticeboard" rel="schoolPage.php?subPage=noticeboard"><img src="background_images/noticeboard.gif" /><br />Noticeboard</div>
<div class="option" title="Links" rel="schoolPage.php?subPage=editLinks"><img src="background_images/links.gif" /><br />Links</div>
</div>