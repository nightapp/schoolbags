This folder contains data to be placed to customer's IIS websites.
 Hello Liam